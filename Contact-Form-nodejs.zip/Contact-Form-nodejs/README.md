# Contact Form Node.js

Simple contact form system using node.js with nodemailer

## Instalation

Install all dependencies

```
npm install
```

Run app

```
npm start
```

## Built With

* Node.Js
* Express.Js
* Nodemailer
* Skeleton.Css

## Author
Neeraj
## Why

* Practise
